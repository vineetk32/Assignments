README
------

Please use add intel_mpich2_hydra-101 before compiling.
